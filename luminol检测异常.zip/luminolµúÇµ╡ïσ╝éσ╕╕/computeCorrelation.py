from luminol.correlator import Correlator
import pandas as pd
from luminol.modules.time_series import TimeSeries

# table = pd.read_csv('./cleaned_lime.csv')
# print(table)
# s1 = table.set_index('Time').T.to_dict('list')

my_correlator = Correlator('./BX0101_ZK214.csv' ,'./BX0101_IK1.csv')

print(my_correlator.get_correlation_result().coefficient)
# my_correlator.get_correlation_result()