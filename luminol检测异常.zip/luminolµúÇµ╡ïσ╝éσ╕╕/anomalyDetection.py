import time
from luminol.anomaly_detector import AnomalyDetector
from luminol.correlator import Correlator
import pandas as pd

# 将毫秒级时间戳转化为格式化时间
def timeStamp2time(ms_timeStamp):
    s_timeStamp = float(ms_timeStamp / 1000)
    timeArray = time.localtime(s_timeStamp)
    otherStyleTime = time.strftime("%Y-%m-%d %H:%M:%S", timeArray)
    return otherStyleTime

# inputTable = pd.read_csv('./data/Ingraphs.latency.csv') # 读取CSV文件
inputTable = pd.read_csv('lime.csv')
inputTable.info()   # 获取读出的csv文件的基本信息

my_detector = AnomalyDetector('./cleaned_lime.csv', score_threshold=1.0)
score = my_detector.get_all_scores()    # 获得每个数据点的anomaly Score
for timestamp, vale in score.iteritems():   # 打印anomaly Score
    print(timestamp, vale)

anomalies = my_detector.get_anomalies() # 获得出现异常的时间窗口
for a in anomalies:
    time_period = a.get_time_window()
    print("（%s, %s）" % (timeStamp2time(time_period[0]), timeStamp2time(time_period[1])))


# print(len(inputTable.iloc[:,0]))
# inputTable.set_index('Time')
# for i in range(len(inputTable.iloc[:,0])):
# print(inputTable)

# print(type(inputTable.iloc[2:3,1]))