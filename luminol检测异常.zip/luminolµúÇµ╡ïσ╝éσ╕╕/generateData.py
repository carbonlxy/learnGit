import pandas as pd
import time
table = pd.read_csv('/Users/xy/Desktop/project/卫星数据9.26/刘云/2017-2018(9.19)北交/TJ3.csv')
columnsName = table.columns.values.tolist() # 获取列名列表
# del columnsName[1:3]
del columnsName[0]
del columnsName[2]
print(columnsName)
table.drop(columnsName, axis=1, inplace=True)
print(table)

table.to_csv('lime.csv', index=False)
table1 = pd.read_csv('lime.csv', dtype=str)
table2 = pd.DataFrame(columns=table.columns.values.tolist())
print(table2)

for i in range(len(table.iloc[:, 0])):
    if str(table.iloc[i, 1]) != "nan":
        time_struct = time.strptime(table.iloc[i, 0][:19], "%Y/%m/%d %H:%M:%S")  # 根据指定的格式把一个时间字符串解析为时间元组
        table.iloc[i, 0] = time.strftime("%Y-%m-%d %H:%M:%S", time_struct)  # 将时间元组转换为指定格式的时间字符串

        table2 = table2.append(table.iloc[i, :], ignore_index=True)  #
        print(table.iloc[i, :])

table2.to_csv('../BX0101_TJ4.csv', index=False)